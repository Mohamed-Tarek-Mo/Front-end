import React from "react";

export default function Account() {
  var codes = [
    { Name: "dummy1", Describtion: "some discribtion", Date: "20/7/2019" },
    { Name: "dummy2", Describtion: "some discribtion", Date: "30/7/2018" },
    { Name: "dummy3", Describtion: "some discribtion", Date: "10/7/2020" },
  ];
  return (
    <div className="text-center">
      <div className="row p-1 my-5">
        <div className="col-4">
          <span className="fw-bold">Name:</span> Mohamed Tarek Mohamed
        </div>
        <div className="col-4">
          <span className="fw-bold">Username:</span> Mohamed-MO
        </div>
        <div className="col-4">
          <a className="btn btn-dark" href="/CodeEditor">
            Change Password
          </a>
        </div>
      </div>
      <table class="table table-hover">
        <thead class="table-dark">
          <tr>
            <th scope="col">Project Name</th>
            <th scope="col">Project Describtion</th>
            <th scope="col">Last Modefied</th>
          </tr>
        </thead>

        <tbody>
          {codes.map((code) => {
            return (
              <tr>
                <td>{code.Name}</td>
                <td>{code.Describtion}</td>
                <td>{code.Date}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
