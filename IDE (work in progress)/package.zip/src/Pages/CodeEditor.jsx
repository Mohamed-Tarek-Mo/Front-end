import React, { useRef, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlay } from "@fortawesome/free-solid-svg-icons";
import { Editor } from "@monaco-editor/react";
import { XTerm } from "xterm-for-react";
import { FitAddon } from "xterm-addon-fit";
import { type } from "@testing-library/user-event/dist/type";

export default function CodeEditor() {
  /*
      Fectch or Get data from API and 

  useEffect(()=>{
    axios.get("https://jsonplaceholder.typicode.com/posts/10")
    .then((response)=>{
      // console.log(response);
      setLoading(false)
      setError("")
      setProject(response.data)

    }).catch((error)=>{
      setLoading(false);
      setError("something went wrong");
      setProject({});
    })
  },[]);*/

  const [contentMarkdown, setContentMarkdown] = useState("#Welcome to our IDE");
  const [contentdata, setContentdata] = useState("Hello, World!");
  // const [Loading , setLoading] = useState(true)
  // const [Error , setError] = useState("")
  // const [Project , setProject] = useState({})
  const editorRef = useRef(null);
  const handleEditorDidMount = (editor, monaco) => {
    editorRef.current = editor;
  };
  const handleSave = () => {
    console.log(editorRef.current.getValue());
  };

  const xtermRef = React.useRef(null);
  let myBuffer = [],
    keysEntered,
    pattern = /^[ A-Za-z0-9_@./#&+-]*$/;
  const fitAddon = new FitAddon();

  React.useEffect(() => {
    // You can call any method in XTerm.js by using 'xterm xtermRef.current.terminal.[What you want to call]
    xtermRef.current.terminal.writeln(contentdata);
    xtermRef.current.terminal.loadAddon(fitAddon);
    //fitAddon.fit();
  }, []);

  return (
    <div className="row p-1 bg-dark mb-5">
      <div className="col-3">asd</div>
      <div className="col-9">
        <div className="row">
          <div className="row m-1">
            <div className="col-5 col-lg-3 text-white text-center pt-2 ">
              Language
            </div>
            <select className="col-4 col-lg-2">
              <option value="Python">Python</option>
              <option value="C++">C++</option>
              <option value="C">C</option>
            </select>
            <div className="col-lg-4 col-1"></div>
            <button className="btn btn-success col-2 col-lg-2">
              Run
              <FontAwesomeIcon icon={faPlay} className="mx-2" />
            </button>
          </div>
          <div className="row p-2">
            <div className="col-12">
              <Editor
                height="50vh"
                theme="vs-dark"
                saveViewState={true}
                loading="Loading..."
                defaultLanguage="python"
                value={contentMarkdown}
                onChange={(value) => setContentMarkdown(value)}
                onMount={handleEditorDidMount}
              />
            </div>
          </div>
          <div className="row text-center">
            <div className="col-12 mt-3" id="terminal-container">
              <XTerm
                ref={xtermRef}
                onKey={(key) => {
                  if (key.key.match(pattern)) {
                    myBuffer.push(key.key);
                  } else if (myBuffer.length != 0 && key.key == "\x7F") {
                    myBuffer.pop();
                  } else if (key.key === "\r") {
                    console.log("enter");
                  }
                }}
                onLineFeed={() => {
                  keysEntered = myBuffer.join("");
                  myBuffer = [];
                }}
                onData={(e) => {
                  console.log(e);
                  console.log(contentdata);
                  setContentdata(contentdata + e);
                  console.log(contentdata);
                }}
              />
              <button
                className="btn btn-outline-light col-3 my-2"
                onClick={handleSave}
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
