import React from "react";

export default function Footer() {
  return (
    <div className="fixed-bottom">
      <footer className="bg-black text-white p-1">
        <div className="text-center">All Copyrights &copy; reserved</div>
      </footer>
    </div>
  );
}
